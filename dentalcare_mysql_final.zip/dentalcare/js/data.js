/**
 * DentalCare · data.js
 * Store central de datos (mock).
 * En producción, estos objetos se reemplazarían
 * por llamadas a una API REST o base de datos local.
 */

const DB = {

  /* ── Pacientes ─────────────────────────────── */
  pacientes: [
    {
      id: 'P001',
      nombre: 'María García Ríos',
      iniciales: 'MG',
      avatarClass: 'av-teal',
      edad: 28,
      telefono: '987-654-321',
      fechaNacimiento: '1998-03-12',
      alergias: ['Penicilina'],
      tratamiento: 'ortodoncia',
      expediente: '#0021',
    },
    {
      id: 'P002',
      nombre: 'Pedro Vargas Mendoza',
      iniciales: 'PV',
      avatarClass: 'av-blue',
      edad: 45,
      telefono: '976-543-210',
      fechaNacimiento: '1981-07-22',
      alergias: [],
      tratamiento: 'endodoncia',
      expediente: '#0018',
    },
    {
      id: 'P003',
      nombre: 'Karla Rodríguez Soto',
      iniciales: 'KR',
      avatarClass: 'av-amber',
      edad: 35,
      telefono: '965-432-109',
      fechaNacimiento: '1991-11-05',
      alergias: [],
      tratamiento: 'consulta',
      expediente: '#0034',
    },
    {
      id: 'P004',
      nombre: 'Andrés Torres Fuentes',
      iniciales: 'AT',
      avatarClass: 'av-teal',
      edad: 19,
      telefono: '954-321-098',
      fechaNacimiento: '2007-02-14',
      alergias: [],
      tratamiento: 'ortodoncia',
      expediente: '#0029',
    },
  ],

  /* ── Citas ──────────────────────────────────── */
  citas: [
    { id: 'C001', pacienteId: 'P001', tipo: 'ortodoncia', fecha: '2026-04-28', hora: '9:00', duracion: 45 },
    { id: 'C002', pacienteId: 'P003', tipo: 'consulta',   fecha: '2026-04-29', hora: '9:00', duracion: 30 },
    { id: 'C003', pacienteId: 'P002', tipo: 'endodoncia', fecha: '2026-04-29', hora: '10:00', duracion: 60 },
    { id: 'C004', pacienteId: 'P004', tipo: 'ortodoncia', fecha: '2026-05-02', hora: '10:00', duracion: 45 },
  ],

  /* ── Roles ──────────────────────────────────── */
  roles: {
    secretaria: {
      nombre: 'Ana Flores',
      titulo: 'Secretaria',
      iniciales: 'AF',
      navDeshabilitado: ['finanzas'],
      navOculto: [],
    },
    residente: {
      nombre: 'Dr. Carlos Soto',
      titulo: 'Residente',
      iniciales: 'CS',
      navDeshabilitado: ['finanzas'],
      navOculto: [],
    },
    doctor: {
      nombre: 'Dra. Patricia Leva',
      titulo: 'Doctor Principal',
      iniciales: 'PL',
      navDeshabilitado: [],
      navOculto: [],
    },
  },

  /* ── Finanzas (resumen del mes) ─────────────── */
  finanzas: {
    cobradoMes:   4320,
    pendienteMes:  940,
    citasCompletas: 43,
    citasTotales:   48,
    movimientos: [
      { descripcion: 'García M. — Mensualidad Ortod.', fecha: 'Hoy', metodo: 'Efectivo', monto: 180,  tipo: 'ingreso' },
      { descripcion: 'Torres F. — 1ª consulta',        fecha: 'Ayer', metodo: 'Tarjeta',  monto: 80,   tipo: 'ingreso' },
      { descripcion: 'Vargas P. — Endodoncia sesión 2',fecha: '28 abr', metodo: 'Pendiente', monto: 350, tipo: 'pendiente' },
      { descripcion: 'López T. — Ortodoncia mes 8',    fecha: '27 abr', metodo: 'Yape',    monto: 180,  tipo: 'ingreso' },
    ],
  },

};

export default DB;
