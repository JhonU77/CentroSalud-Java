/**
 * DentalCare · roles.js
 * Control de acceso según rol del usuario.
 * Muestra/oculta secciones del menú y botones.
 */

import DB from './data.js';

let rolActual = 'secretaria';

/**
 * Aplica los permisos del rol seleccionado a la UI.
 * @param {string} rol - 'secretaria' | 'residente' | 'doctor'
 */
export function setRol(rol) {
  rolActual = rol;
  const config = DB.roles[rol];
  if (!config) return;

  // — Actualizar display del usuario en sidebar —
  document.getElementById('role-avatar').textContent  = config.iniciales;
  document.getElementById('role-name').textContent    = config.nombre;
  document.getElementById('role-title').textContent   = config.titulo;

  // — Resaltar botón de rol activo —
  document.querySelectorAll('.role-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.rol === rol);
  });

  // — Aplicar permisos de navegación —
  document.querySelectorAll('.nav-item[data-screen]').forEach(item => {
    const screen = item.dataset.screen;
    item.classList.toggle('disabled', config.navDeshabilitado.includes(screen));
  });

  // — Mostrar/ocultar botones según rol —
  applyButtonVisibility(rol);
}

/**
 * Controla qué botones del topbar son visibles por rol.
 */
function applyButtonVisibility(rol) {
  const btnNuevaCita     = document.getElementById('btn-nueva-cita');
  const btnNuevoPaciente = document.getElementById('btn-nuevo-paciente');

  if (btnNuevaCita)     btnNuevaCita.style.display     = '';
  if (btnNuevoPaciente) btnNuevoPaciente.style.display  =
    rol === 'secretaria' ? '' : 'none';
}

export function getRolActual() {
  return rolActual;
}

/**
 * Inicializa los botones de cambio de rol.
 */
export function initRoles() {
  document.querySelectorAll('.role-btn[data-rol]').forEach(btn => {
    btn.addEventListener('click', () => setRol(btn.dataset.rol));
  });

  // Rol inicial
  setRol('secretaria');
}
