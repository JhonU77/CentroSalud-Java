/**
 * DentalCare · app.js  (v2 — con autenticación integrada)
 * Punto de entrada principal. Inicializa sesión, permisos y módulos.
 */

import { getSession, logout, ROL_PERMISOS } from './auth.js';
import { initModals, initNavigation, initPatientSearch, showToast, openModal, closeModal } from './ui.js';
import { initAgenda, initWeekNav }  from './modules/agenda.js';
import { initPacientes }            from './modules/pacientes.js';
import { initFlujo }                from './modules/flujo.js';

document.addEventListener('DOMContentLoaded', () => {

  /* ── 1. Verificar sesión ── */
  const session = getSession();
  if (!session) { window.location.href = 'login.html'; return; }

  /* ── 2. Aplicar datos de sesión a la UI ── */
  applySession(session);

  /* ── 3. Aplicar permisos del rol ── */
  applyPermisos(session.rol);

  /* ── 4-7. Módulos ── */
  initNavigation();
  initModals();
  initAgenda();
  initWeekNav();
  initPacientes();
  initFlujo();

  initPatientSearch('input-paciente-cita', 'dropdown-pacientes-cita', (id) => {
    console.log('Paciente seleccionado:', id);
  });

  /* ── 8. Botones topbar ── */
  document.getElementById('btn-nueva-cita')?.addEventListener('click', () => openModal('nueva-cita'));
  document.getElementById('btn-nuevo-paciente')?.addEventListener('click', () => openModal('nuevo-paciente'));
  document.getElementById('btn-recordatorios')?.addEventListener('click', () => openModal('recordatorio'));

  /* ── 9. Logout ── */
  const btnLogout = document.getElementById('btn-logout');
  if (btnLogout) {
    btnLogout.addEventListener('mouseenter', () => {
      btnLogout.style.background = 'rgba(255,255,255,.12)';
      btnLogout.style.color = 'rgba(255,255,255,.8)';
    });
    btnLogout.addEventListener('mouseleave', () => {
      btnLogout.style.background = 'rgba(255,255,255,.07)';
      btnLogout.style.color = 'rgba(255,255,255,.5)';
    });
    btnLogout.addEventListener('click', () => { if (confirm('¿Cerrar sesión?')) logout(); });
  }

  /* ── 10-13. Modales acciones ── */
  document.getElementById('btn-enviar-todos')?.addEventListener('click', () => {
    closeModal('recordatorio'); showToast('Todos los recordatorios enviados ✓', 'success');
  });
  document.getElementById('btn-ver-expediente')?.addEventListener('click', () => {
    closeModal('ver-cita'); document.querySelector('.nav-item[data-screen="endodoncia"]')?.click();
  });
  document.getElementById('btn-ver-tratamiento')?.addEventListener('click', () => {
    closeModal('ver-paciente'); document.querySelector('.nav-item[data-screen="ortodoncia"]')?.click();
  });
  document.getElementById('btn-nueva-cita-desde-paciente')?.addEventListener('click', () => {
    closeModal('ver-paciente'); openModal('nueva-cita');
  });
  document.getElementById('btn-cancelar-cita')?.addEventListener('click', () => {
    closeModal('ver-cita'); showToast('Cita cancelada', 'error');
  });

  console.log(`%cDentalCare · ${session.nombre} (${session.rol}) ✓`, 'color:#1D9E75;font-weight:600');
});

function applySession(session) {
  const avatarEl = document.getElementById('role-avatar');
  const nameEl   = document.getElementById('role-name');
  const titleEl  = document.getElementById('role-title');
  const emailEl  = document.getElementById('role-email');
  if (avatarEl) { avatarEl.textContent = session.iniciales || session.nombre.slice(0,2).toUpperCase(); avatarEl.style.background = session.avatar || 'var(--teal-400)'; }
  if (nameEl)   nameEl.textContent  = session.nombre;
  if (titleEl)  titleEl.textContent = session.titulo;
  if (emailEl)  emailEl.textContent = session.email;

  const titleBar = document.getElementById('screen-title');
  const hora = new Date().getHours();
  const saludo = hora < 12 ? 'Buenos días' : hora < 19 ? 'Buenas tardes' : 'Buenas noches';
  if (titleBar) {
    titleBar.textContent = `${saludo}, ${session.nombre.split(' ')[0]}`;
    setTimeout(() => { if (titleBar) titleBar.textContent = 'Agenda semanal'; }, 2500);
  }
}

function applyPermisos(rol) {
  const permisos = ROL_PERMISOS[rol];
  if (!permisos) return;
  document.querySelectorAll('.nav-item[data-screen]').forEach(item => {
    const allowed = permisos.screens.includes(item.dataset.screen);
    item.classList.toggle('disabled', !allowed);
    item.style.opacity = allowed ? '' : '0.25';
  });
  const btnNP = document.getElementById('btn-nuevo-paciente');
  if (btnNP) btnNP.style.display = rol === 'secretaria' ? '' : 'none';

  setTimeout(() => {
    const tc = document.getElementById('toast-container');
    if (!tc) return;
    const colores = { secretaria: 'var(--teal-600)', residente: 'var(--blue-600)', doctor: 'var(--amber-600)' };
    const textos  = {
      secretaria: 'Vista Secretaria — Agenda y pacientes',
      residente:  'Vista Residente — Expedientes y tratamientos',
      doctor:     'Vista Doctor Principal — Acceso total',
    };
    const t = document.createElement('div');
    t.className = 'toast';
    t.style.background = colores[rol];
    t.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>${textos[rol]}`;
    tc.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(()=>t.remove(),300); }, 3500);
  }, 400);
}
