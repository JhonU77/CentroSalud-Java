/**
 * DentalCare · ui.js
 * Utilidades de interfaz: toasts, modales, navegación.
 */

/* ── Toast ──────────────────────────────────── */
export function showToast(mensaje, tipo = '') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast${tipo ? ' ' + tipo : ''}`;

  const icon = tipo === 'success'
    ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>`
    : tipo === 'error'
    ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 6L6 18M6 6l12 12"/></svg>`
    : tipo === 'warning'
    ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`
    : '';

  toast.innerHTML = icon + mensaje;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* ── Modal ──────────────────────────────────── */
export function openModal(nombre) {
  const overlay = document.getElementById(`modal-${nombre}`);
  if (overlay) overlay.classList.add('open');
}

export function closeModal(nombre) {
  const overlay = document.getElementById(`modal-${nombre}`);
  if (overlay) overlay.classList.remove('open');
}

export function initModals() {
  // Cerrar al hacer clic fuera
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });

  // Cerrar con Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.open')
        .forEach(m => m.classList.remove('open'));
    }
  });

  // Botones .modal-close
  document.querySelectorAll('.modal-close[data-modal]').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.modal));
  });
}

/* ── Navegación ─────────────────────────────── */
const SCREEN_META = {
  agenda:     { titulo: 'Agenda semanal',                 sub: 'Semana del 28 abr – 3 may, 2026 · 8 citas programadas' },
  pacientes:  { titulo: 'Pacientes',                      sub: '34 pacientes activos este mes' },
  ortodoncia: { titulo: 'Ortodoncia — Seguimiento mensual', sub: 'María García Ríos · Mes 15 de 24' },
  endodoncia: { titulo: 'Endodoncia — Expediente activo', sub: 'Pedro Vargas · Diente 36 · 3 conductos' },
  finanzas:   { titulo: 'Finanzas del mes',               sub: 'Abril 2026 — Resumen de cobros' },
  flujo:      { titulo: 'Flujo de trabajo',               sub: '7 pasos: de paciente nuevo a nota clínica' },
};

export function showScreen(nombre) {
  // Ocultar todas las screens
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  // Desactivar todos los nav-items
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  // Activar la screen solicitada
  const screen = document.getElementById(`screen-${nombre}`);
  if (screen) screen.classList.add('active');

  // Activar el nav-item correspondiente
  const navItem = document.querySelector(`.nav-item[data-screen="${nombre}"]`);
  if (navItem) navItem.classList.add('active');

  // Actualizar topbar
  const meta = SCREEN_META[nombre] || {};
  const titleEl = document.getElementById('screen-title');
  const subEl   = document.getElementById('screen-breadcrumb');
  if (titleEl) titleEl.textContent = meta.titulo || nombre;
  if (subEl)   subEl.textContent   = meta.sub    || '';
}

export function initNavigation() {
  document.querySelectorAll('.nav-item[data-screen]').forEach(item => {
    item.addEventListener('click', () => {
      if (item.classList.contains('disabled')) return;
      showScreen(item.dataset.screen);
    });
  });
}

/* ── Validación de formularios ──────────────── */
export function validateForm(formEl) {
  let valid = true;
  formEl.querySelectorAll('[data-required]').forEach(field => {
    const errorEl = formEl.querySelector(`[data-error="${field.name}"]`);
    if (!field.value.trim()) {
      field.classList.add('error');
      if (errorEl) errorEl.textContent = 'Este campo es obligatorio';
      valid = false;
    } else {
      field.classList.remove('error');
      if (errorEl) errorEl.textContent = '';
    }
  });
  return valid;
}

/* ── Dropdown de búsqueda de pacientes ─────── */
export function initPatientSearch(inputId, dropdownId, onSelect) {
  const input    = document.getElementById(inputId);
  const dropdown = document.getElementById(dropdownId);
  if (!input || !dropdown) return;

  input.addEventListener('input', () => {
    dropdown.classList.toggle('open', input.value.length > 0);
  });

  // Filtrar visualmente los items (búsqueda simple)
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    dropdown.querySelectorAll('.dropdown-item').forEach(item => {
      const name = item.querySelector('.dropdown-item-name')?.textContent.toLowerCase() || '';
      item.style.display = name.includes(q) ? '' : 'none';
    });
  });

  dropdown.querySelectorAll('.dropdown-item').forEach(item => {
    item.addEventListener('click', () => {
      const name = item.querySelector('.dropdown-item-name')?.textContent || '';
      input.value = name;
      dropdown.classList.remove('open');
      if (onSelect) onSelect(item.dataset.id);
    });
  });

  // Cerrar al hacer clic afuera
  document.addEventListener('click', (e) => {
    if (!input.contains(e.target) && !dropdown.contains(e.target)) {
      dropdown.classList.remove('open');
    }
  });
}
