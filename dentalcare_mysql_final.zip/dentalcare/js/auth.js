/**
 * DentalCare · auth.js  (v2 — conectado a la API)
 *
 * Cambia API_BASE a la URL de tu servidor cuando lo despliegues.
 * En desarrollo: http://localhost:3001
 */

export const API_BASE = 'http://localhost:3001/api';
const SESSION_KEY     = 'dentalcare_session';
const TOKEN_KEY       = 'dentalcare_token';

/* ── Permisos por rol ── */
export const ROL_PERMISOS = {
  secretaria: {
    screens:  ['agenda', 'pacientes', 'ortodoncia', 'flujo'],
    canEdit:  ['citas', 'pacientes', 'pagos'],
  },
  residente: {
    screens:  ['agenda', 'pacientes', 'ortodoncia', 'endodoncia', 'flujo'],
    canEdit:  ['notas', 'archivos', 'ortodoncia', 'endodoncia'],
  },
  doctor: {
    screens:  ['agenda', 'pacientes', 'ortodoncia', 'endodoncia', 'finanzas', 'flujo'],
    canEdit:  ['todo'],
  },
};

/* ── Login (llama a la API) ── */
export async function login(email, password) {
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!data.ok) return { ok: false, error: data.error };

    // Guardar token y sesión
    sessionStorage.setItem(TOKEN_KEY,    data.token);
    sessionStorage.setItem(SESSION_KEY,  JSON.stringify(data.user));
    return { ok: true, user: data.user };
  } catch {
    // Fallback demo si no hay servidor corriendo
    return loginDemo(email, password);
  }
}

/* ── Fallback demo (sin servidor) ── */
function loginDemo(email, password) {
  const USERS = {
    'secretaria@dentalcare.pe': { id:'u001', nombre:'Ana Flores',         email:'secretaria@dentalcare.pe', rol:'secretaria', titulo:'Secretaria',           iniciales:'AF', avatar:'#1D9E75' },
    'residente@dentalcare.pe':  { id:'u002', nombre:'Dr. Carlos Soto',    email:'residente@dentalcare.pe',  rol:'residente',  titulo:'Odontólogo Residente', iniciales:'CS', avatar:'#378ADD' },
    'doctor@dentalcare.pe':     { id:'u003', nombre:'Dra. Patricia Leva', email:'doctor@dentalcare.pe',     rol:'doctor',     titulo:'Odontóloga Principal', iniciales:'PL', avatar:'#854F0B' },
  };
  const user = USERS[email.toLowerCase().trim()];
  if (!user || password !== 'dental123') {
    return { ok: false, error: 'Credenciales incorrectas' };
  }
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
  sessionStorage.setItem(TOKEN_KEY, 'demo-token');
  return { ok: true, user };
}

/* ── Logout ── */
export function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(TOKEN_KEY);
  window.location.href = 'login.html';
}

/* ── Obtener sesión ── */
export function getSession() {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

/* ── Obtener token para peticiones API ── */
export function getToken() {
  return sessionStorage.getItem(TOKEN_KEY);
}

/* ── Headers con auth para fetch ── */
export function authHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${getToken()}`,
  };
}

/* ── Fetch con auth automático ── */
export async function apiFetch(endpoint, options = {}) {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: { ...authHeaders(), ...(options.headers || {}) },
  });
  const data = await res.json();
  if (res.status === 401) { logout(); return null; }
  return data;
}

export function isLoggedIn()   { return getSession() !== null; }
export function requireAuth()  { if (!isLoggedIn()) { window.location.href = 'login.html'; return false; } return true; }
export function canAccessScreen(s) {
  const session = getSession();
  if (!session) return false;
  const p = ROL_PERMISOS[session.rol];
  return p?.screens.includes(s) || p?.canEdit.includes('todo') || false;
}
