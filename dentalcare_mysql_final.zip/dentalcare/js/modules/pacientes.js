/**
 * DentalCare · modules/pacientes.js
 * Lógica de la pantalla de Pacientes.
 */

import DB from '../data.js';
import { showToast, openModal, closeModal } from '../ui.js';

/**
 * Inicializa la pantalla de Pacientes.
 */
export function initPacientes() {
  initFiltros();
  initBusqueda();
  initNuevoPaciente();
  initPatientRowClicks();
}

/* ── Chips de filtro ────────────────────────── */
function initFiltros() {
  document.querySelectorAll('.patient-filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.patient-filter-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      filtrarPacientes(chip.dataset.filtro);
    });
  });
}

function filtrarPacientes(filtro) {
  const rows = document.querySelectorAll('.patient-row[data-tratamiento]');
  rows.forEach(row => {
    const visible = filtro === 'todos' || row.dataset.tratamiento === filtro;
    row.style.display = visible ? '' : 'none';
  });
}

/* ── Búsqueda por texto ─────────────────────── */
function initBusqueda() {
  const input = document.getElementById('patient-search-main');
  if (!input) return;

  input.addEventListener('input', () => {
    const q = input.value.toLowerCase().trim();
    document.querySelectorAll('.patient-row').forEach(row => {
      const name = row.querySelector('.patient-name')?.textContent.toLowerCase() || '';
      const meta = row.querySelector('.patient-meta')?.textContent.toLowerCase() || '';
      row.style.display = (!q || name.includes(q) || meta.includes(q)) ? '' : 'none';
    });
  });
}

/* ── Formulario nuevo paciente ──────────────── */
function initNuevoPaciente() {
  const btn = document.getElementById('btn-guardar-paciente');
  if (!btn) return;

  btn.addEventListener('click', () => {
    const nombre   = document.getElementById('np-nombre')?.value.trim();
    const apellido = document.getElementById('np-apellido')?.value.trim();
    const telefono = document.getElementById('np-telefono')?.value.trim();

    let valido = true;

    [
      { id: 'np-nombre',   errorId: 'np-nombre-error' },
      { id: 'np-apellido', errorId: 'np-apellido-error' },
      { id: 'np-telefono', errorId: 'np-telefono-error' },
    ].forEach(({ id, errorId }) => {
      const field = document.getElementById(id);
      const errorEl = document.getElementById(errorId);
      if (!field?.value.trim()) {
        field?.classList.add('error');
        if (errorEl) errorEl.textContent = 'Campo obligatorio';
        valido = false;
      } else {
        field?.classList.remove('error');
        if (errorEl) errorEl.textContent = '';
      }
    });

    if (!valido) return;

    closeModal('nuevo-paciente');
    showToast(`Paciente ${nombre} ${apellido} registrado ✓`, 'success');
    limpiarFormPaciente();
    // TODO: persistir en DB y actualizar la lista
  });
}

function limpiarFormPaciente() {
  ['np-nombre','np-apellido','np-telefono','np-fecha','np-alergias','np-motivo']
    .forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
}

/* ── Click en fila de paciente ──────────────── */
function initPatientRowClicks() {
  document.querySelectorAll('.patient-row').forEach(row => {
    row.addEventListener('click', () => openModal('ver-paciente'));
  });
}
