/**
 * DentalCare · modules/archivos.js
 * Módulo de subida, preview y gestión de archivos.
 * Soporta: imágenes (JPG, PNG, WEBP) y radiografías (DICOM simulado, JPG).
 *
 * En producción: reemplazar uploadFile() con fetch() a tu endpoint real.
 */

/* ── Constantes ─────────────────────────────── */
const MAX_SIZE_MB   = 10;
const MAX_SIZE_BYTES = MAX_SIZE_MB * 1024 * 1024;
const ALLOWED_TYPES  = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const ALLOWED_EXT    = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.dcm'];

/**
 * Inicializa todas las zonas de drop de la app.
 * Llámalo desde app.js una vez que el DOM esté listo.
 */
export function initUploadZones() {
  document.querySelectorAll('[data-upload-zone]').forEach(zone => {
    initZone(zone);
  });
}

/* ── Inicializar una zona individual ─────────── */
function initZone(zone) {
  const input       = zone.querySelector('input[type="file"]');
  const previewGrid = zone.querySelector('[data-preview-grid]');
  const context     = zone.dataset.uploadZone; // 'ortho-foto' | 'radio' | etc.

  if (!input) return;

  // Clic en la zona → activar input
  zone.addEventListener('click', (e) => {
    if (e.target.closest('[data-preview-grid]')) return;
    input.click();
  });

  // Drag & Drop
  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('drag-over');
  });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    handleFiles(Array.from(e.dataTransfer.files), zone, previewGrid, context);
  });

  // Selección con input
  input.addEventListener('change', () => {
    handleFiles(Array.from(input.files), zone, previewGrid, context);
    input.value = ''; // reset para permitir subir el mismo archivo
  });
}

/* ── Procesar archivos seleccionados ─────────── */
function handleFiles(files, zone, previewGrid, context) {
  files.forEach(file => {
    const error = validateFile(file);
    if (error) {
      showZoneError(zone, error);
      return;
    }
    processFile(file, previewGrid, context);
  });
}

/* ── Validación ─────────────────────────────── */
function validateFile(file) {
  if (file.size > MAX_SIZE_BYTES) {
    return `"${file.name}" supera el límite de ${MAX_SIZE_MB} MB.`;
  }
  const ext = '.' + file.name.split('.').pop().toLowerCase();
  const typeOk = ALLOWED_TYPES.includes(file.type) || ext === '.dcm';
  if (!typeOk) {
    return `"${file.name}" no es un formato válido. Usa JPG, PNG, WEBP o DCM.`;
  }
  return null;
}

/* ── Procesar y mostrar preview ─────────────── */
function processFile(file, previewGrid, context) {
  if (!previewGrid) return;

  const id   = `file-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const card = buildPreviewCard(id, file, context);
  previewGrid.appendChild(card);

  const isDicom = file.name.toLowerCase().endsWith('.dcm');

  if (isDicom) {
    // Para DICOM real usarías cornerstone.js; aquí mostramos placeholder
    card.querySelector('[data-img]').style.display = 'none';
    card.querySelector('[data-dicom-placeholder]').style.display = 'flex';
    simulateUpload(card, file);
  } else {
    // Imagen normal → FileReader para preview
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = card.querySelector('[data-img]');
      img.src = e.target.result;
      img.style.display = 'block';
      simulateUpload(card, file);
    };
    reader.readAsDataURL(file);
  }
}

/* ── Construir tarjeta de preview ────────────── */
function buildPreviewCard(id, file, context) {
  const card = document.createElement('div');
  card.className = 'upload-card';
  card.dataset.id = id;

  const ext      = file.name.split('.').pop().toUpperCase();
  const sizeLabel = formatBytes(file.size);
  const isDicom   = ext === 'DCM';

  card.innerHTML = `
    <div class="upload-card-thumb">
      <img data-img src="" alt="${escHtml(file.name)}" style="display:none">
      <div data-dicom-placeholder class="dicom-placeholder" style="display:none">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="10" r="3"/><path d="M7 21v-1a5 5 0 0110 0v1"/></svg>
        <span>DICOM</span>
      </div>
      <div class="upload-card-overlay">
        <button class="upload-btn-action" data-action="preview" data-id="${id}" title="Ver">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
        <button class="upload-btn-action" data-action="delete" data-id="${id}" title="Eliminar">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
        </button>
      </div>
    </div>
    <div class="upload-card-info">
      <div class="upload-card-name" title="${escHtml(file.name)}">${escHtml(truncate(file.name, 22))}</div>
      <div class="upload-card-meta">${ext} · ${sizeLabel}</div>
    </div>
    <div class="upload-progress-bar">
      <div class="upload-progress-fill" data-progress></div>
    </div>
    <div class="upload-card-status" data-status>
      <span class="status-dot uploading"></span>
      <span data-status-text>Subiendo…</span>
    </div>
  `;

  // Eventos de botones
  card.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
    e.stopPropagation();
    deleteCard(card);
  });

  card.querySelector('[data-action="preview"]').addEventListener('click', (e) => {
    e.stopPropagation();
    openPreviewModal(card, file);
  });

  return card;
}

/* ── Simular progreso de subida ──────────────── */
function simulateUpload(card, file) {
  /**
   * En producción, reemplaza esto por un fetch real con
   * XMLHttpRequest para obtener el progreso real:
   *
   * const xhr = new XMLHttpRequest();
   * xhr.upload.addEventListener('progress', (e) => {
   *   const pct = Math.round((e.loaded / e.total) * 100);
   *   updateProgress(card, pct);
   * });
   * xhr.open('POST', '/api/archivos/upload');
   * xhr.send(formData);
   */
  const progressEl = card.querySelector('[data-progress]');
  const statusText = card.querySelector('[data-status-text]');
  const statusDot  = card.querySelector('.status-dot');

  let pct = 0;
  const interval = setInterval(() => {
    pct += Math.random() * 18 + 5;
    if (pct >= 100) {
      pct = 100;
      clearInterval(interval);
      progressEl.style.width = '100%';
      progressEl.style.background = 'var(--teal-400)';
      statusText.textContent = 'Subido ✓';
      statusDot.className = 'status-dot done';
      setTimeout(() => {
        card.querySelector('.upload-progress-bar').style.display = 'none';
        card.querySelector('[data-status]').style.display = 'none';
      }, 1200);
    } else {
      progressEl.style.width = `${pct}%`;
    }
  }, 180);
}

/* ── Eliminar tarjeta con animación ──────────── */
function deleteCard(card) {
  card.style.transition = 'opacity 0.25s, transform 0.25s';
  card.style.opacity    = '0';
  card.style.transform  = 'scale(0.9)';
  setTimeout(() => card.remove(), 260);
}

/* ── Modal de preview ampliado ───────────────── */
function openPreviewModal(card, file) {
  const existing = document.getElementById('preview-lightbox');
  if (existing) existing.remove();

  const img = card.querySelector('[data-img]');
  const src = img?.src;

  const lb = document.createElement('div');
  lb.id = 'preview-lightbox';
  lb.innerHTML = `
    <div class="lightbox-overlay">
      <div class="lightbox-content">
        <div class="lightbox-header">
          <div>
            <div class="lightbox-title">${escHtml(file.name)}</div>
            <div class="lightbox-meta">${formatBytes(file.size)} · ${new Date().toLocaleDateString('es-PE')}</div>
          </div>
          <button class="lightbox-close" id="lightbox-close-btn">✕</button>
        </div>
        <div class="lightbox-body">
          ${src && img.style.display !== 'none'
            ? `<img src="${src}" class="lightbox-img" alt="${escHtml(file.name)}">`
            : `<div class="dicom-fullview">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--gray-400)" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="10" r="3"/><path d="M7 21v-1a5 5 0 0110 0v1"/></svg>
                <div style="color:var(--gray-500);font-size:13px;margin-top:10px">Vista DICOM — instala cornerstone.js para visualización clínica completa</div>
              </div>`
          }
        </div>
        <div class="lightbox-footer">
          <button class="btn btn-sm" id="lightbox-close-btn2">Cerrar</button>
          <a class="btn btn-sm btn-primary" ${src ? `href="${src}" download="${escHtml(file.name)}"` : ''}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Descargar
          </a>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(lb);

  const close = () => {
    lb.style.opacity = '0';
    lb.style.transition = 'opacity 0.2s';
    setTimeout(() => lb.remove(), 200);
  };

  lb.querySelector('#lightbox-close-btn')?.addEventListener('click', close);
  lb.querySelector('#lightbox-close-btn2')?.addEventListener('click', close);
  lb.querySelector('.lightbox-overlay')?.addEventListener('click', (e) => {
    if (e.target === lb.querySelector('.lightbox-overlay')) close();
  });
  document.addEventListener('keydown', function handler(e) {
    if (e.key === 'Escape') { close(); document.removeEventListener('keydown', handler); }
  });
}

/* ── Error en zona ──────────────────────────── */
function showZoneError(zone, msg) {
  const existing = zone.querySelector('.zone-error');
  if (existing) existing.remove();

  const errEl = document.createElement('div');
  errEl.className = 'zone-error';
  errEl.textContent = msg;
  zone.appendChild(errEl);
  setTimeout(() => errEl.remove(), 4000);
}

/* ── Helpers ─────────────────────────────────── */
function formatBytes(bytes) {
  if (bytes < 1024)        return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function truncate(str, max) {
  return str.length > max ? str.slice(0, max - 1) + '…' : str;
}

function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
