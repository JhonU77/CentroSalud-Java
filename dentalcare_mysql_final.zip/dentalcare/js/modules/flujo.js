/**
 * DentalCare · modules/flujo.js
 * Lógica de la pantalla Flujo de trabajo.
 */

/**
 * Inicializa el acordeón del flujo de trabajo.
 */
export function initFlujo() {
  document.querySelectorAll('.flow-step').forEach(step => {
    step.addEventListener('click', () => toggleStep(step));
  });
}

function toggleStep(stepEl) {
  const detail = stepEl.querySelector('.step-detail');
  const arrow  = stepEl.querySelector('.step-arrow');
  if (!detail) return;

  const isOpen = detail.style.display === 'block';
  detail.style.display = isOpen ? 'none' : 'block';
  if (arrow) arrow.classList.toggle('open', !isOpen);
}
