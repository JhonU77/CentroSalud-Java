/**
 * DentalCare · modules/agenda.js
 * Lógica de la pantalla de Agenda semanal.
 */

import { showToast, openModal, closeModal } from '../ui.js';

/**
 * Inicializa los eventos de la pantalla de Agenda.
 */
export function initAgenda() {
  initCitaClicks();
  initNuevaCita();
}

/* ── Click en citas del calendario ─────────── */
function initCitaClicks() {
  document.querySelectorAll('.appt').forEach(appt => {
    appt.addEventListener('click', (e) => {
      e.stopPropagation();
      openModal('ver-cita');
    });
  });

  // Click en celda vacía → abrir nueva cita
  document.querySelectorAll('.cal-cell').forEach(cell => {
    cell.addEventListener('click', () => {
      if (!cell.querySelector('.appt')) {
        openModal('nueva-cita');
      }
    });
  });
}

/* ── Formulario de nueva cita ───────────────── */
function initNuevaCita() {
  // Selector de tipo
  document.querySelectorAll('.type-option').forEach(opt => {
    opt.addEventListener('click', () => selectTipo(opt));
  });

  // Botón guardar
  const btnGuardar = document.getElementById('btn-guardar-cita');
  if (btnGuardar) {
    btnGuardar.addEventListener('click', guardarCita);
  }

  // Botón cancelar cita (modal ver-cita)
  const btnCancelar = document.getElementById('btn-cancelar-cita');
  if (btnCancelar) {
    btnCancelar.addEventListener('click', () => {
      closeModal('ver-cita');
      showToast('Cita cancelada', 'error');
    });
  }
}

function selectTipo(optionEl) {
  document.querySelectorAll('.type-option').forEach(o => {
    o.classList.remove('sel-ortho', 'sel-endo', 'sel-consult');
  });
  const tipo = optionEl.dataset.tipo || '';
  optionEl.classList.add(`sel-${tipo || 'ortho'}`);
}

function guardarCita() {
  const paciente = document.getElementById('input-paciente-cita')?.value?.trim();
  const fecha    = document.getElementById('input-fecha-cita')?.value;
  const hora     = document.getElementById('input-hora-cita')?.value;

  if (!paciente) {
    document.getElementById('input-paciente-cita')?.classList.add('error');
    showToast('Selecciona un paciente', 'warning');
    return;
  }
  if (!fecha || !hora) {
    showToast('Completa fecha y hora', 'warning');
    return;
  }

  closeModal('nueva-cita');
  showToast('Cita agendada correctamente ✓', 'success');
  // TODO: agregar al DOM del calendario y persistir en DB
}

/* ── Navegación semanal ─────────────────────── */
export function initWeekNav() {
  const btnPrev = document.getElementById('btn-semana-prev');
  const btnNext = document.getElementById('btn-semana-next');
  const btnHoy  = document.getElementById('btn-hoy');

  // Aquí iría la lógica de cambio de semana
  // En producción haría un fetch a la API con la semana seleccionada
  if (btnPrev) btnPrev.addEventListener('click', () => showToast('Navegando a semana anterior'));
  if (btnNext) btnNext.addEventListener('click', () => showToast('Navegando a semana siguiente'));
  if (btnHoy)  btnHoy.addEventListener('click',  () => showToast('Volviendo a esta semana'));
}
