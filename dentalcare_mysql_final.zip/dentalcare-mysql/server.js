/**
 * DentalCare · server.js  (MySQL)
 *
 * ─────────────────────────────────────────────
 * INICIO RÁPIDO
 * ─────────────────────────────────────────────
 * 1. Copia .env.example → .env  y edita tus datos MySQL
 * 2. npm install
 * 3. npm run setup   (crea tablas + datos demo)
 * 4. npm run dev     (servidor en http://localhost:3001)
 * ─────────────────────────────────────────────
 */

require('dotenv').config();

const express   = require('express');
const cors      = require('cors');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');
const path      = require('path');
const fs        = require('fs');

/* ── Base de datos ── */
const db = require('./db/connection');

/* ── App ── */
const app  = express();
const PORT = process.env.PORT || 3001;

/* ── Seguridad ── */
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:8080',
  'http://localhost:63342',   // IntelliJ IDEA built-in server
  process.env.FRONTEND_URL,
].filter(Boolean);

app.use(cors({ origin: allowedOrigins, credentials: true }));

/* ── Rate limiting ── */
app.use('/api/auth/login', rateLimit({
  windowMs: 15 * 60 * 1000, max: 10,
  message: { ok: false, error: 'Demasiados intentos. Espera 15 minutos.' },
}));
app.use('/api/', rateLimit({
  windowMs: 60 * 1000, max: 300,
  message: { ok: false, error: 'Demasiadas peticiones.' },
}));

/* ── Body ── */
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

/* ── Archivos estáticos subidos ── */
const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
app.use('/uploads', express.static(UPLOAD_DIR));

/* ── Servir frontend si existe en la carpeta hermana ── */
const FRONTEND = path.join(__dirname, '..', 'dentalcare');
if (fs.existsSync(FRONTEND)) {
  app.use('/', express.static(FRONTEND));
  console.log(`🌐 Frontend: ${FRONTEND}`);
}

/* ── Rutas API ── */
app.get('/api/health', async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ ok: true, version: '1.0.0', db: 'MySQL OK', time: new Date().toISOString() });
  } catch {
    res.status(500).json({ ok: false, db: 'MySQL ERROR' });
  }
});

app.use('/api/auth',         require('./routes/auth')(db));
app.use('/api/pacientes',    require('./routes/pacientes')(db));
app.use('/api/citas',        require('./routes/citas')(db));
app.use('/api/pagos',        require('./routes/pagos')(db));
app.use('/api/tratamientos', require('./routes/tratamientos')(db));
app.use('/api/archivos',     require('./routes/archivos')(db));

/* ── Dashboard rápido ── */
const { requireAuth } = require('./middleware/auth');

app.get('/api/dashboard', requireAuth, async (req, res) => {
  try {
    const hoy = new Date().toISOString().slice(0, 10);
    const mes  = hoy.slice(0, 7);

    const [[{ citas_hoy }]]           = await db.query(`SELECT COUNT(*) AS citas_hoy FROM citas WHERE fecha = ? AND estado = 'programada'`, [hoy]);
    const [[{ pacientes_activos }]]   = await db.query(`SELECT COUNT(*) AS pacientes_activos FROM pacientes WHERE activo = 1`);
    const [[{ ortodoncias_activas }]] = await db.query(`SELECT COUNT(*) AS ortodoncias_activas FROM ortodoncias WHERE estado = 'activo'`);
    const [[{ endodoncias_activas }]] = await db.query(`SELECT COUNT(*) AS endodoncias_activas FROM endodoncias WHERE estado = 'activo'`);
    const [[{ cobrado_mes }]]         = await db.query(`SELECT COALESCE(SUM(monto),0) AS cobrado_mes FROM pagos WHERE DATE_FORMAT(fecha,'%Y-%m') = ? AND estado = 'pagado'`, [mes]);
    const [[{ pendiente_mes }]]       = await db.query(`SELECT COALESCE(SUM(monto),0) AS pendiente_mes FROM pagos WHERE DATE_FORMAT(fecha,'%Y-%m') = ? AND estado = 'pendiente'`, [mes]);

    const [citas_de_hoy] = await db.query(`
      SELECT c.*, CONCAT(p.nombre,' ',p.apellido) AS paciente_nombre, p.alergias
      FROM citas c
      JOIN pacientes p ON p.id = c.paciente_id
      WHERE c.fecha = ? AND c.estado = 'programada'
      ORDER BY c.hora
    `, [hoy]);

    res.json({
      ok: true,
      data: {
        stats: { citas_hoy, pacientes_activos, ortodoncias_activas, endodoncias_activas, cobrado_mes, pendiente_mes },
        citas_hoy: citas_de_hoy.map(c => ({ ...c, alergias: JSON.parse(c.alergias || '[]') })),
      }
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/* ── 404 ── */
app.use('/api/*', (req, res) => {
  res.status(404).json({ ok: false, error: `Ruta no encontrada: ${req.path}` });
});

/* ── Error global ── */
app.use((err, req, res, next) => {
  console.error('❌', err.message);
  if (err.code === 'LIMIT_FILE_SIZE')
    return res.status(413).json({ ok: false, error: 'Archivo demasiado grande (máx. 10 MB)' });
  res.status(500).json({ ok: false, error: err.message || 'Error interno del servidor' });
});

/* ── Start ── */
app.listen(PORT, () => {
  console.log(`\n🦷 DentalCare Backend (MySQL) → http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/api/health\n`);
});
