/**
 * DentalCare · routes/pacientes.js  (MySQL) — corregido
 */

const express = require('express');
const { requireAuth, requireRol } = require('../middleware/auth');
const router = express.Router();
const uid = () => Math.random().toString(16).slice(2, 10);

module.exports = (db) => {

  /* GET /api/pacientes */
  router.get('/', requireAuth, async (req, res) => {
    try {
      const { q, tratamiento, deuda } = req.query;
      let sql = `
        SELECT p.*,
          COALESCE((SELECT SUM(monto) FROM pagos pg
                    WHERE pg.paciente_id = p.id AND pg.estado = 'pendiente'), 0) AS deuda_total,
          (SELECT CONCAT(fecha, ' ', hora) FROM citas c
           WHERE c.paciente_id = p.id AND c.fecha >= CURDATE() AND c.estado = 'programada'
           ORDER BY fecha, hora LIMIT 1) AS proxima_cita
        FROM pacientes p
        WHERE p.activo = 1`;
      const params = [];

      if (q) {
        sql += ` AND (p.nombre LIKE ? OR p.apellido LIKE ? OR p.telefono LIKE ? OR p.expediente LIKE ?)`;
        const like = `%${q}%`;
        params.push(like, like, like, like);
      }
      if (tratamiento === 'ortodoncia')
        sql += ` AND EXISTS (SELECT 1 FROM ortodoncias o WHERE o.paciente_id = p.id AND o.estado = 'activo')`;
      if (tratamiento === 'endodoncia')
        sql += ` AND EXISTS (SELECT 1 FROM endodoncias e WHERE e.paciente_id = p.id AND e.estado = 'activo')`;
      if (deuda === 'true')
        sql += ` AND EXISTS (SELECT 1 FROM pagos pg WHERE pg.paciente_id = p.id AND pg.estado = 'pendiente')`;

      sql += ` ORDER BY p.apellido, p.nombre`;

      const [rows] = await db.query(sql, params);
      const pacientes = rows.map(p => ({
        ...p,
        alergias:    typeof p.alergias === 'string' ? JSON.parse(p.alergias) : (p.alergias || []),
        deuda_total: parseFloat(p.deuda_total) || 0,
      }));

      res.json({ ok: true, data: pacientes, total: pacientes.length });
    } catch (err) {
      console.error('GET /pacientes:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* GET /api/pacientes/:id */
  router.get('/:id', requireAuth, async (req, res) => {
    try {
      const [filas] = await db.query(
        'SELECT * FROM pacientes WHERE id = ? AND activo = 1', [req.params.id]
      );
      const p = filas[0];
      if (!p) return res.status(404).json({ ok: false, error: 'Paciente no encontrado' });

      const [citas]       = await db.query(`SELECT * FROM citas WHERE paciente_id = ? ORDER BY fecha DESC, hora DESC LIMIT 20`, [p.id]);
      const [pagos]       = await db.query(`SELECT * FROM pagos WHERE paciente_id = ? ORDER BY fecha DESC`, [p.id]);
      const [ortRows]     = await db.query(`SELECT * FROM ortodoncias WHERE paciente_id = ?`, [p.id]);
      const [endodoncias] = await db.query(`SELECT * FROM endodoncias WHERE paciente_id = ?`, [p.id]);
      const [archivos]    = await db.query(`SELECT * FROM archivos WHERE paciente_id = ? ORDER BY created_at DESC`, [p.id]);

      const ortodoncia = ortRows[0] || null;

      res.json({
        ok: true,
        data: {
          ...p,
          alergias:    typeof p.alergias === 'string' ? JSON.parse(p.alergias) : (p.alergias || []),
          citas,
          pagos,
          ortodoncia,
          endodoncias,
          archivos,
          deuda_total: pagos
            .filter(pg => pg.estado === 'pendiente')
            .reduce((s, pg) => s + parseFloat(pg.monto), 0),
        }
      });
    } catch (err) {
      console.error('GET /pacientes/:id:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/pacientes */
  router.post('/', requireAuth, async (req, res) => {
    try {
      const { nombre, apellido, fecha_nacimiento, telefono, email, alergias, motivo_inicial } = req.body;
      if (!nombre?.trim() || !apellido?.trim() || !telefono?.trim())
        return res.status(400).json({ ok: false, error: 'Nombre, apellido y teléfono son obligatorios' });

      // Generar expediente correlativo
      const [lastRows] = await db.query(
        `SELECT expediente FROM pacientes ORDER BY CAST(REPLACE(expediente, '#', '') AS UNSIGNED) DESC LIMIT 1`
      );
      const num        = lastRows[0] ? parseInt(lastRows[0].expediente.replace('#', '')) + 1 : 1;
      const expediente = `#${String(num).padStart(4, '0')}`;

      const newId = uid();
      await db.query(`
        INSERT INTO pacientes
          (id, nombre, apellido, fecha_nacimiento, telefono, email, alergias, motivo_inicial, expediente, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        newId,
        nombre.trim(), apellido.trim(),
        fecha_nacimiento || null,
        telefono.trim(),
        email?.trim() || null,
        JSON.stringify(alergias || []),
        motivo_inicial?.trim() || '',
        expediente,
        req.user.id,
      ]);

      const [newRows] = await db.query('SELECT * FROM pacientes WHERE id = ?', [newId]);
      const nuevo = newRows[0];
      res.status(201).json({
        ok: true,
        data: { ...nuevo, alergias: typeof nuevo.alergias === 'string' ? JSON.parse(nuevo.alergias) : (nuevo.alergias || []) }
      });
    } catch (err) {
      console.error('POST /pacientes:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* PUT /api/pacientes/:id */
  router.put('/:id', requireAuth, async (req, res) => {
    try {
      const { nombre, apellido, fecha_nacimiento, telefono, email, alergias, notas_generales } = req.body;
      await db.query(`
        UPDATE pacientes SET
          nombre           = COALESCE(?, nombre),
          apellido         = COALESCE(?, apellido),
          fecha_nacimiento = COALESCE(?, fecha_nacimiento),
          telefono         = COALESCE(?, telefono),
          email            = COALESCE(?, email),
          alergias         = COALESCE(?, alergias),
          notas_generales  = COALESCE(?, notas_generales)
        WHERE id = ?
      `, [
        nombre || null, apellido || null, fecha_nacimiento || null,
        telefono || null, email || null,
        alergias ? JSON.stringify(alergias) : null,
        notas_generales || null,
        req.params.id,
      ]);

      const [rows] = await db.query('SELECT * FROM pacientes WHERE id = ?', [req.params.id]);
      const updated = rows[0];
      res.json({
        ok: true,
        data: { ...updated, alergias: typeof updated.alergias === 'string' ? JSON.parse(updated.alergias) : (updated.alergias || []) }
      });
    } catch (err) {
      console.error('PUT /pacientes/:id:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* DELETE /api/pacientes/:id */
  router.delete('/:id', requireAuth, requireRol('doctor'), async (req, res) => {
    try {
      await db.query(`UPDATE pacientes SET activo = 0 WHERE id = ?`, [req.params.id]);
      res.json({ ok: true, message: 'Paciente desactivado' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
};
