/**
 * DentalCare · routes/pagos.js  (MySQL) — corregido
 */

const express = require('express');
const { requireAuth, requireRol } = require('../middleware/auth');
const router = express.Router();
const uid = () => Math.random().toString(16).slice(2, 10);

module.exports = (db) => {

  /* GET /api/pagos */
  router.get('/', requireAuth, async (req, res) => {
    try {
      const { paciente_id, estado, desde, hasta } = req.query;
      let sql = `
        SELECT pg.*, CONCAT(p.nombre, ' ', p.apellido) AS paciente_nombre
        FROM pagos pg
        JOIN pacientes p ON p.id = pg.paciente_id
        WHERE 1=1`;
      const params = [];

      if (paciente_id) { sql += ' AND pg.paciente_id = ?'; params.push(paciente_id); }
      if (estado)      { sql += ' AND pg.estado = ?';      params.push(estado); }
      if (desde)       { sql += ' AND pg.fecha >= ?';      params.push(desde); }
      if (hasta)       { sql += ' AND pg.fecha <= ?';      params.push(hasta); }
      sql += ' ORDER BY pg.fecha DESC';

      const [pagos] = await db.query(sql, params);
      res.json({ ok: true, data: pagos, total: pagos.length });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* GET /api/pagos/resumen-mes */
  router.get('/resumen-mes', requireAuth, requireRol('doctor'), async (req, res) => {
    try {
      const mes = req.query.mes || new Date().toISOString().slice(0, 7);
      const [rows] = await db.query(`
        SELECT
          COALESCE(SUM(CASE WHEN estado = 'pagado'    THEN monto ELSE 0 END), 0) AS cobrado,
          COALESCE(SUM(CASE WHEN estado = 'pendiente' THEN monto ELSE 0 END), 0) AS pendiente,
          COUNT(CASE WHEN estado = 'pagado'    THEN 1 END) AS num_pagados,
          COUNT(CASE WHEN estado = 'pendiente' THEN 1 END) AS num_pendientes
        FROM pagos
        WHERE DATE_FORMAT(fecha, '%Y-%m') = ?
      `, [mes]);
      res.json({ ok: true, data: rows[0] });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/pagos */
  router.post('/', requireAuth, async (req, res) => {
    try {
      const { paciente_id, concepto, monto, metodo, estado, fecha } = req.body;
      if (!paciente_id || !concepto || !monto)
        return res.status(400).json({ ok: false, error: 'paciente_id, concepto y monto son obligatorios' });

      const fechaPago = fecha || new Date().toISOString().slice(0, 10);
      const newId = uid();
      const [result] = await db.query(`
        INSERT INTO pagos (id, paciente_id, concepto, monto, metodo, estado, fecha, registrado_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        newId,
        paciente_id, concepto, parseFloat(monto),
        metodo  || 'efectivo',
        estado  || 'pagado',
        fechaPago,
        req.user.id,
      ]);

      const [rows] = await db.query('SELECT * FROM pagos WHERE id = ?', [newId]);
      res.status(201).json({ ok: true, data: rows[0] });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* PUT /api/pagos/:id/marcar-pagado */
  router.put('/:id/marcar-pagado', requireAuth, async (req, res) => {
    try {
      await db.query(
        `UPDATE pagos SET estado = 'pagado', metodo = COALESCE(?, metodo) WHERE id = ?`,
        [req.body.metodo || null, req.params.id]
      );
      res.json({ ok: true, message: 'Pago marcado como pagado' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
};
