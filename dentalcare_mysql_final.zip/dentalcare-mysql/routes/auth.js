/**
 * DentalCare · routes/auth.js  (MySQL) — corregido
 */

const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { requireAuth } = require('../middleware/auth');
const router  = express.Router();

module.exports = (db) => {

  /* POST /api/auth/login */
  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password)
        return res.status(400).json({ ok: false, error: 'Email y contraseña requeridos' });

      const [rows] = await db.query(
        'SELECT * FROM usuarios WHERE email = ? AND activo = 1',
        [email.toLowerCase().trim()]
      );
      const user = rows[0];

      if (!user)
        return res.status(401).json({ ok: false, error: 'No existe una cuenta con ese correo' });

      const valid = await bcrypt.compare(password, user.password);
      if (!valid)
        return res.status(401).json({ ok: false, error: 'Contraseña incorrecta' });

      const payload = {
        id:        user.id,
        nombre:    user.nombre,
        email:     user.email,
        rol:       user.rol,
        titulo:    user.titulo,
        iniciales: user.iniciales,
        avatar:    user.avatar_color,
      };
      const token = jwt.sign(
        payload,
        process.env.JWT_SECRET || 'dentalcare_secret',
        { expiresIn: '8h' }
      );

      res.json({ ok: true, token, user: payload });
    } catch (err) {
      console.error('POST /auth/login:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* GET /api/auth/me */
  router.get('/me', requireAuth, (req, res) => {
    res.json({ ok: true, user: req.user });
  });

  /* POST /api/auth/logout */
  router.post('/logout', requireAuth, (req, res) => {
    res.json({ ok: true, message: 'Sesión cerrada. Elimina el token del cliente.' });
  });

  return router;
};
