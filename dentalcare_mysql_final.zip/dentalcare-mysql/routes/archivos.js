/**
 * DentalCare · routes/archivos.js  (MySQL)
 */

const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { requireAuth } = require('../middleware/auth');

const router     = express.Router();
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(UPLOAD_DIR, req.body.paciente_id || 'sin-paciente');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext    = path.extname(file.originalname).toLowerCase();
    const base   = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    cb(null, `${base}_${unique}${ext}`);
  },
});

const fileFilter = (req, file, cb) => {
  const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.dcm', '.pdf', '.doc', '.docx'];
  const ext     = path.extname(file.originalname).toLowerCase();
  allowed.includes(ext) ? cb(null, true) : cb(new Error(`Tipo no permitido: ${ext}`), false);
};

const upload = multer({ storage, fileFilter, limits: { fileSize: 10 * 1024 * 1024 } });

module.exports = (db) => {

  /* POST /api/archivos/upload */
  router.post('/upload', requireAuth, upload.single('archivo'), async (req, res) => {
    try {
      if (!req.file)
        return res.status(400).json({ ok: false, error: 'No se recibió ningún archivo' });

      const { paciente_id, tipo, subtipo, nota } = req.body;
      if (!paciente_id || !tipo) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ ok: false, error: 'paciente_id y tipo son obligatorios' });
      }

      const newId = uid();
      await db.query(`
        INSERT INTO archivos (id, paciente_id, tipo, subtipo, filename, original_name, size_bytes, mime_type, nota, subido_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        newId,
        paciente_id, tipo, subtipo || '',
        req.file.filename, req.file.originalname,
        req.file.size, req.file.mimetype,
        nota || '', req.user.id,
      ]);

      const [newRows2] = await db.query('SELECT * FROM archivos WHERE id = ?', [newId]);
      const nuevo = newRows2[0];
      res.status(201).json({
        ok: true,
        data: { ...nuevo, url: `/uploads/${paciente_id}/${req.file.filename}` },
      });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* GET /api/archivos/:paciente_id */
  router.get('/:paciente_id', requireAuth, async (req, res) => {
    try {
      const { tipo } = req.query;
      let sql = `
        SELECT a.*, u.nombre AS subido_nombre
        FROM archivos a
        LEFT JOIN usuarios u ON u.id = a.subido_por
        WHERE a.paciente_id = ?`;
      const params = [req.params.paciente_id];

      if (tipo) { sql += ' AND a.tipo = ?'; params.push(tipo); }
      sql += ' ORDER BY a.created_at DESC';

      const [archivos] = await db.query(sql, params);
      const data = archivos.map(a => ({
        ...a,
        url: `/uploads/${req.params.paciente_id}/${a.filename}`,
      }));
      res.json({ ok: true, data, total: data.length });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* DELETE /api/archivos/:id */
  router.delete('/:id', requireAuth, async (req, res) => {
    try {
      const [[archivo]] = await db.query('SELECT * FROM archivos WHERE id = ?', [req.params.id]);
      if (!archivo) return res.status(404).json({ ok: false, error: 'Archivo no encontrado' });

      const filePath = path.join(UPLOAD_DIR, archivo.paciente_id, archivo.filename);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

      await db.query('DELETE FROM archivos WHERE id = ?', [req.params.id]);
      res.json({ ok: true, message: 'Archivo eliminado' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
};
