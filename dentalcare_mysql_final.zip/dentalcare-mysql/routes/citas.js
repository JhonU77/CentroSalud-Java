/**
 * DentalCare · routes/citas.js  (MySQL) — corregido
 */

const express = require('express');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();
const uid = () => Math.random().toString(16).slice(2, 10);

module.exports = (db) => {

  /* GET /api/citas */
  router.get('/', requireAuth, async (req, res) => {
    try {
      const { fecha, desde, hasta, paciente_id, estado } = req.query;
      let sql = `
        SELECT c.*,
          CONCAT(p.nombre, ' ', p.apellido) AS paciente_nombre,
          p.expediente,
          p.alergias
        FROM citas c
        JOIN pacientes p ON p.id = c.paciente_id
        WHERE 1=1`;
      const params = [];

      if (fecha)       { sql += ' AND c.fecha = ?';       params.push(fecha); }
      if (desde)       { sql += ' AND c.fecha >= ?';      params.push(desde); }
      if (hasta)       { sql += ' AND c.fecha <= ?';      params.push(hasta); }
      if (paciente_id) { sql += ' AND c.paciente_id = ?'; params.push(paciente_id); }
      if (estado)      { sql += ' AND c.estado = ?';      params.push(estado); }
      sql += ' ORDER BY c.fecha, c.hora';

      const [citas] = await db.query(sql, params);
      res.json({ ok: true, data: citas, total: citas.length });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/citas */
  router.post('/', requireAuth, async (req, res) => {
    try {
      const { paciente_id, tipo, fecha, hora, duracion_min, notas, recordatorio } = req.body;
      if (!paciente_id || !tipo || !fecha || !hora)
        return res.status(400).json({ ok: false, error: 'paciente_id, tipo, fecha y hora son obligatorios' });

      const [conflicto] = await db.query(
        `SELECT id FROM citas WHERE fecha = ? AND hora = ? AND estado = 'programada'`,
        [fecha, hora]
      );
      if (conflicto[0])
        return res.status(409).json({ ok: false, error: 'Ya existe una cita en ese horario' });

      const newId = uid();
      const [result] = await db.query(`
        INSERT INTO citas (id, paciente_id, tipo, fecha, hora, duracion_min, notas, recordatorio, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [newId, paciente_id, tipo, fecha, hora,
          duracion_min || 45, notas || '', recordatorio || '24h', req.user.id]);

      const [rows] = await db.query('SELECT * FROM citas WHERE id = ?', [newId]);
      res.status(201).json({ ok: true, data: rows[0] });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* PUT /api/citas/:id */
  router.put('/:id', requireAuth, async (req, res) => {
    try {
      const { fecha, hora, duracion_min, estado, notas } = req.body;
      await db.query(`
        UPDATE citas SET
          fecha        = COALESCE(?, fecha),
          hora         = COALESCE(?, hora),
          duracion_min = COALESCE(?, duracion_min),
          estado       = COALESCE(?, estado),
          notas        = COALESCE(?, notas)
        WHERE id = ?
      `, [fecha || null, hora || null, duracion_min || null,
          estado || null, notas || null, req.params.id]);

      const [rows] = await db.query('SELECT * FROM citas WHERE id = ?', [req.params.id]);
      res.json({ ok: true, data: rows[0] });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* DELETE /api/citas/:id */
  router.delete('/:id', requireAuth, async (req, res) => {
    try {
      await db.query(`UPDATE citas SET estado = 'cancelada' WHERE id = ?`, [req.params.id]);
      res.json({ ok: true, message: 'Cita cancelada' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
};
