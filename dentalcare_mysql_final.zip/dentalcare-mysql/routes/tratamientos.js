/**
 * DentalCare · routes/tratamientos.js  (MySQL) — corregido
 */

const express = require('express');
const { requireAuth, requireRol } = require('../middleware/auth');
const router = express.Router();
const uid = () => Math.random().toString(16).slice(2, 10);

module.exports = (db) => {

  /* ══ ORTODONCIA ══════════════════════════════ */

  /* GET /api/tratamientos/ortodoncia/:paciente_id */
  router.get('/ortodoncia/:paciente_id', requireAuth, async (req, res) => {
    try {
      const [rows] = await db.query(
        `SELECT * FROM ortodoncias WHERE paciente_id = ? AND estado = 'activo'`,
        [req.params.paciente_id]
      );
      const o = rows[0];
      if (!o) return res.status(404).json({ ok: false, error: 'Sin ortodoncia activa' });

      const [sesiones] = await db.query(`
        SELECT s.*, u.nombre AS realizado_nombre
        FROM ortodoncia_sesiones s
        LEFT JOIN usuarios u ON u.id = s.realizado_por
        WHERE s.ortodoncia_id = ?
        ORDER BY s.mes_numero DESC
      `, [o.id]);

      const progreso = Math.min(100, Math.round((sesiones.length / o.duracion_meses) * 100));
      res.json({ ok: true, data: { ...o, sesiones, progreso } });
    } catch (err) {
      console.error('GET ortodoncia:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/tratamientos/ortodoncia */
  router.post('/ortodoncia', requireAuth, requireRol('doctor', 'residente'), async (req, res) => {
    try {
      const { paciente_id, tipo_aparato, fecha_inicio, duracion_meses, costo_total } = req.body;
      if (!paciente_id || !fecha_inicio)
        return res.status(400).json({ ok: false, error: 'paciente_id y fecha_inicio son obligatorios' });

      const [existRows] = await db.query(
        `SELECT id FROM ortodoncias WHERE paciente_id = ? AND estado = 'activo'`, [paciente_id]
      );
      if (existRows[0])
        return res.status(409).json({ ok: false, error: 'Ya existe un tratamiento activo de ortodoncia' });

      const newId = uid();
      await db.query(`
        INSERT INTO ortodoncias (id, paciente_id, tipo_aparato, fecha_inicio, duracion_meses, costo_total)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [newId, paciente_id, tipo_aparato || 'metálico', fecha_inicio, duracion_meses || 24, costo_total || 0]);

      const [newRows] = await db.query('SELECT * FROM ortodoncias WHERE id = ?', [newId]);
      res.status(201).json({ ok: true, data: newRows[0] });
    } catch (err) {
      console.error('POST ortodoncia:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/tratamientos/ortodoncia/:id/sesion */
  router.post('/ortodoncia/:id/sesion', requireAuth, requireRol('doctor', 'residente'), async (req, res) => {
    try {
      const { mes_numero, fecha, arco_activo, ligas, nota, foto_path } = req.body;
      if (!mes_numero || !fecha)
        return res.status(400).json({ ok: false, error: 'mes_numero y fecha son obligatorios' });

      const sId = uid();
      await db.query(`
        INSERT INTO ortodoncia_sesiones
          (id, ortodoncia_id, mes_numero, fecha, arco_activo, ligas, nota, foto_path, realizado_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [sId, req.params.id, mes_numero, fecha,
          arco_activo || '', ligas || '', nota || '', foto_path || '',
          req.user.id]);

      const [newRows] = await db.query('SELECT * FROM ortodoncia_sesiones WHERE id = ?', [sId]);
      res.status(201).json({ ok: true, data: newRows[0] });
    } catch (err) {
      console.error('POST ortodoncia/sesion:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* ══ ENDODONCIA ══════════════════════════════ */

  /* GET /api/tratamientos/endodoncia/:paciente_id */
  router.get('/endodoncia/:paciente_id', requireAuth, async (req, res) => {
    try {
      const [endos] = await db.query(
        `SELECT * FROM endodoncias WHERE paciente_id = ?`, [req.params.paciente_id]
      );

      const result = await Promise.all(endos.map(async e => {
        const [sesiones] = await db.query(`
          SELECT es.*, u.nombre AS realizado_nombre
          FROM endodoncia_sesiones es
          LEFT JOIN usuarios u ON u.id = es.realizado_por
          WHERE es.endodoncia_id = ?
          ORDER BY es.numero_sesion ASC
        `, [e.id]);

        return {
          ...e,
          sesiones: sesiones.map(s => ({
            ...s,
            conductos: s.conductos_json
              ? (typeof s.conductos_json === 'string' ? JSON.parse(s.conductos_json) : s.conductos_json)
              : [],
          })),
        };
      }));

      res.json({ ok: true, data: result });
    } catch (err) {
      console.error('GET endodoncia:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/tratamientos/endodoncia */
  router.post('/endodoncia', requireAuth, requireRol('doctor', 'residente'), async (req, res) => {
    try {
      const { paciente_id, diente, num_conductos, costo } = req.body;
      if (!paciente_id || !diente)
        return res.status(400).json({ ok: false, error: 'paciente_id y diente son obligatorios' });

      const newId2 = uid();
      await db.query(`
        INSERT INTO endodoncias (id, paciente_id, diente, num_conductos, costo)
        VALUES (?, ?, ?, ?, ?)
      `, [newId2, paciente_id, diente, num_conductos || 1, costo || 0]);

      const [newRows] = await db.query('SELECT * FROM endodoncias WHERE id = ?', [newId2]);
      res.status(201).json({ ok: true, data: newRows[0] });
    } catch (err) {
      console.error('POST endodoncia:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* POST /api/tratamientos/endodoncia/:id/sesion */
  router.post('/endodoncia/:id/sesion', requireAuth, requireRol('doctor', 'residente'), async (req, res) => {
    try {
      const { numero_sesion, fecha, fase_completada, conductos, nota_clinica, radiografia_path } = req.body;
      if (!numero_sesion || !fecha || !fase_completada)
        return res.status(400).json({ ok: false, error: 'numero_sesion, fecha y fase_completada son obligatorios' });

      // Actualizar fase actual
      await db.query(
        `UPDATE endodoncias SET fase_actual = ? WHERE id = ?`,
        [fase_completada, req.params.id]
      );

      const esId = uid();
      await db.query(`
        INSERT INTO endodoncia_sesiones
          (id, endodoncia_id, numero_sesion, fecha, fase_completada, conductos_json, nota_clinica, radiografia_path, realizado_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        esId,
        req.params.id, numero_sesion, fecha, fase_completada,
        JSON.stringify(conductos || []),
        nota_clinica || '',
        radiografia_path || '',
        req.user.id,
      ]);

      const [newRows] = await db.query('SELECT * FROM endodoncia_sesiones WHERE id = ?', [esId]);
      const nueva = newRows[0];
      res.status(201).json({
        ok: true,
        data: {
          ...nueva,
          conductos: typeof nueva.conductos_json === 'string'
            ? JSON.parse(nueva.conductos_json)
            : (nueva.conductos_json || []),
        }
      });
    } catch (err) {
      console.error('POST endodoncia/sesion:', err.message);
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /* PUT /api/tratamientos/endodoncia/:id/completar */
  router.put('/endodoncia/:id/completar', requireAuth, requireRol('doctor'), async (req, res) => {
    try {
      await db.query(
        `UPDATE endodoncias SET estado = 'completado', fase_actual = 5 WHERE id = ?`,
        [req.params.id]
      );
      res.json({ ok: true, message: 'Endodoncia marcada como completada' });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  return router;
};
