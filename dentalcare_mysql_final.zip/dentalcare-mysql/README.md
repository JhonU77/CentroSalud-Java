# DentalCare — Backend MySQL + Frontend

Sistema de gestión para clínica dental.
**Stack:** Node.js · Express · MySQL · HTML/CSS/JS puro

---

## Estructura del proyecto

```
proyecto/
│
├── dentalcare/                  ← FRONTEND (abrir en IntelliJ)
│   ├── login.html               ← Pantalla de inicio de sesión
│   ├── index.html               ← Sistema principal
│   ├── pages/
│   │   └── archivos.html        ← Módulo de radiografías y fotos
│   ├── css/
│   │   ├── variables.css
│   │   ├── base.css
│   │   ├── components.css
│   │   ├── layout.css
│   │   ├── screens.css
│   │   └── upload.css
│   └── js/
│       ├── app.js               ← Punto de entrada
│       ├── auth.js              ← Autenticación + llamadas API
│       ├── ui.js                ← Toast, modales, navegación
│       ├── data.js              ← Datos demo (fallback sin servidor)
│       ├── roles.js             ← Permisos por rol
│       └── modules/
│           ├── agenda.js
│           ├── pacientes.js
│           ├── archivos.js
│           └── flujo.js
│
└── dentalcare-mysql/            ← BACKEND (Node.js + MySQL)
    ├── server.js                ← Servidor principal
    ├── .env.example             ← Plantilla de variables de entorno
    ├── package.json
    ├── db/
    │   ├── connection.js        ← Pool de conexiones MySQL
    │   ├── migrate.js           ← Crea las tablas
    │   └── seed.js              ← Datos de demo
    ├── middleware/
    │   └── auth.js              ← JWT + guards de rol
    └── routes/
        ├── auth.js              ← Login / me
        ├── pacientes.js         ← CRUD pacientes
        ├── citas.js             ← CRUD agenda
        ├── pagos.js             ← Registro de cobros
        ├── tratamientos.js      ← Ortodoncia + Endodoncia
        └── archivos.js          ← Upload de radiografías/fotos
```

---

## Requisitos previos

- **Node.js** v18 o superior → https://nodejs.org
- **MySQL** 8.0 o superior (puede ser XAMPP, WAMP, MySQL Workbench, o instalación directa)
- **IntelliJ IDEA** (cualquier edición, incluida Community)

---

## Paso 1 — Configurar MySQL

### Opción A — Con XAMPP o WAMP
1. Inicia el servicio MySQL desde el panel de control
2. Abre phpMyAdmin o MySQL Workbench
3. No necesitas crear la base de datos manualmente — el script lo hace

### Opción B — MySQL instalado directamente
```sql
-- En MySQL Workbench o terminal:
-- (no es necesario crear la BD, el migrate.js la crea automáticamente)
```

---

## Paso 2 — Configurar el backend

```bash
# Entra a la carpeta del backend
cd dentalcare-mysql

# Copia el archivo de variables de entorno
cp .env.example .env
```

Edita `.env` con tus datos reales:
```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=tu_contraseña_de_mysql
DB_NAME=dentalcare
JWT_SECRET=cualquier_texto_secreto_largo
PORT=3001
```

```bash
# Instala dependencias
npm install

# Crea las tablas e inserta datos de demo
npm run setup

# Inicia el servidor (con auto-reinicio al guardar cambios)
npm run dev
```

El servidor corre en → **http://localhost:3001**
Verifica con → http://localhost:3001/api/health

---

## Paso 3 — Abrir el frontend en IntelliJ IDEA

1. Abre IntelliJ IDEA
2. `File → Open` → selecciona la carpeta **`dentalcare/`**
3. En el panel de archivos, clic derecho sobre **`login.html`**
4. Selecciona **`Open In → Browser → Chrome`** (o el navegador que prefieras)

IntelliJ levanta automáticamente un servidor en `http://localhost:63342`

> ⚠️ No abras `login.html` con doble clic desde el explorador de Windows/Mac.
> El proyecto usa ES6 modules que requieren un servidor HTTP. IntelliJ lo provee automáticamente.

---

## Credenciales de acceso (demo)

| Rol               | Email                        | Contraseña |
|-------------------|------------------------------|------------|
| Secretaria        | secretaria@dentalcare.pe     | dental123  |
| Residente         | residente@dentalcare.pe      | dental123  |
| Doctor Principal  | doctor@dentalcare.pe         | dental123  |

---

## Endpoints de la API

### Auth
```
POST /api/auth/login    → { email, password }
GET  /api/auth/me       → (requiere token)
```

### Pacientes
```
GET    /api/pacientes           → lista con filtros ?q=&tratamiento=&deuda=
GET    /api/pacientes/:id       → detalle completo + citas + pagos + tratamientos
POST   /api/pacientes           → crear paciente
PUT    /api/pacientes/:id       → actualizar
DELETE /api/pacientes/:id       → desactivar (solo doctor)
```

### Citas
```
GET    /api/citas               → ?fecha=&desde=&hasta=&paciente_id=&estado=
POST   /api/citas               → crear cita
PUT    /api/citas/:id           → actualizar / reprogramar
DELETE /api/citas/:id           → cancelar
```

### Pagos
```
GET  /api/pagos                  → ?paciente_id=&estado=&desde=&hasta=
GET  /api/pagos/resumen-mes      → ?mes=YYYY-MM (solo doctor)
POST /api/pagos                  → registrar pago
PUT  /api/pagos/:id/marcar-pagado
```

### Tratamientos
```
GET  /api/tratamientos/ortodoncia/:paciente_id
POST /api/tratamientos/ortodoncia
POST /api/tratamientos/ortodoncia/:id/sesion

GET  /api/tratamientos/endodoncia/:paciente_id
POST /api/tratamientos/endodoncia
POST /api/tratamientos/endodoncia/:id/sesion
PUT  /api/tratamientos/endodoncia/:id/completar
```

### Archivos
```
POST   /api/archivos/upload      → multipart/form-data con campo "archivo"
GET    /api/archivos/:paciente_id → ?tipo=foto|radiografia|documento
DELETE /api/archivos/:id
```

### Dashboard
```
GET /api/dashboard   → stats del día + citas de hoy
```

---

## Cómo enviar peticiones autenticadas

Después del login, guarda el token y envíalo en cada petición:

```javascript
// Login
const res  = await fetch('http://localhost:3001/api/auth/login', {
  method:  'POST',
  headers: { 'Content-Type': 'application/json' },
  body:    JSON.stringify({ email: 'doctor@dentalcare.pe', password: 'dental123' })
});
const { token, user } = await res.json();

// Uso en siguientes peticiones
const pacientes = await fetch('http://localhost:3001/api/pacientes', {
  headers: { 'Authorization': `Bearer ${token}` }
});
```

---

## Notas de seguridad para producción

1. Cambia `JWT_SECRET` en `.env` por una cadena aleatoria larga
2. Usa HTTPS (certificado SSL)
3. Crea un usuario MySQL con permisos limitados solo a la base `dentalcare`
4. Haz backups automáticos de MySQL (`mysqldump`)
5. Coloca el servidor detrás de nginx o Apache como proxy reverso
