/**
 * DentalCare · db/connection.js
 * Pool de conexiones MySQL reutilizable en todas las rutas.
 */

const mysql  = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               parseInt(process.env.DB_PORT || '3306'),
  user:               process.env.DB_USER     || 'root',
  password:           process.env.DB_PASSWORD || '',
  database:           process.env.DB_NAME     || 'dentalcare',
  waitForConnections: true,
  connectionLimit:    10,
  queueLimit:         0,
  timezone:           '+00:00',
  decimalNumbers:     true,
});

/* Verificar conexión al importar */
pool.getConnection()
  .then(conn => {
    console.log(`✅ MySQL conectado → ${process.env.DB_HOST}:${process.env.DB_PORT || 3306}/${process.env.DB_NAME}`);
    conn.release();
  })
  .catch(err => {
    console.error('❌ Error conectando a MySQL:', err.message);
    console.error('   Verifica los datos en el archivo .env');
    process.exit(1);
  });

module.exports = pool;
