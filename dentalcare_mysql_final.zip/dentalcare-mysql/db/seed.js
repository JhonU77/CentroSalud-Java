/**
 * DentalCare · db/seed.js  (MySQL 8.0 CE compatible)
 * IDs generados en Node.js, no en MySQL.
 * Ejecutar: node db/seed.js
 */

const mysql  = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

/* Generador de ID corto (8 chars hex) */
function uid() {
  return Math.random().toString(16).slice(2, 10);
}

async function seed() {
  const conn = await mysql.createConnection({
    host:               process.env.DB_HOST     || 'localhost',
    port:               parseInt(process.env.DB_PORT || '3306'),
    user:               process.env.DB_USER     || 'root',
    password:           process.env.DB_PASSWORD || '',
    database:           process.env.DB_NAME     || 'dentalcare',
    multipleStatements: true,
  });

  console.log('🌱 Sembrando datos de demo en MySQL 8.0...\n');

  try {
    const HASH = await bcrypt.hash('dental123', 10);

    /* ── Limpiar (respetando FK) ── */
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    for (const t of ['ortodoncia_sesiones','endodoncia_sesiones','archivos','pagos',
                     'ortodoncias','endodoncias','citas','pacientes','usuarios']) {
      await conn.query(`TRUNCATE TABLE ${t}`);
    }
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');

    /* ── Usuarios ── */
    const U = { sec:'u001sec1', res:'u002res1', doc:'u003doc1' };
    await conn.query(`
      INSERT INTO usuarios (id, nombre, email, password, rol, titulo, iniciales, avatar_color) VALUES
      (?, 'Ana Flores',         'secretaria@dentalcare.pe', ?, 'secretaria', 'Secretaria',           'AF', '#1D9E75'),
      (?, 'Dr. Carlos Soto',    'residente@dentalcare.pe',  ?, 'residente',  'Odontólogo Residente', 'CS', '#378ADD'),
      (?, 'Dra. Patricia Leva', 'doctor@dentalcare.pe',     ?, 'doctor',     'Odontóloga Principal', 'PL', '#854F0B')
    `, [U.sec, HASH, U.res, HASH, U.doc, HASH]);
    console.log('✅ 3 usuarios');

    /* ── Pacientes ── */
    const P = { p1:'p001a1b2', p2:'p002c3d4', p3:'p003e5f6', p4:'p004g7h8', p5:'p005i9j0' };
    await conn.query(`
      INSERT INTO pacientes (id, expediente, nombre, apellido, fecha_nacimiento, telefono, email, alergias, motivo_inicial, created_by) VALUES
      (?,  '#0021', 'María',  'García Ríos',    '1998-03-12', '987654321', 'maria.garcia@email.com',    '["Penicilina"]', 'Ortodoncia correctiva', ?),
      (?,  '#0018', 'Pedro',  'Vargas Mendoza', '1981-07-22', '976543210', 'pedro.vargas@email.com',    '[]',             'Dolor en muela 36',     ?),
      (?,  '#0034', 'Karla',  'Rodríguez Soto', '1991-11-05', '965432109', 'karla.rodriguez@email.com', '[]',             'Revisión general',      ?),
      (?,  '#0029', 'Andrés', 'Torres Fuentes', '2007-02-14', '954321098', 'andres.torres@email.com',   '[]',             'Ortodoncia preventiva', ?),
      (?,  '#0011', 'Lucía',  'Chávez Paredes', '1995-08-30', '943210987', 'lucia.chavez@email.com',    '["Ibuprofeno"]', 'Endodoncia diente 46',  ?)
    `, [P.p1,U.sec, P.p2,U.sec, P.p3,U.sec, P.p4,U.sec, P.p5,U.sec]);
    console.log('✅ 5 pacientes');

    /* ── Citas ── */
    const citas = [
      [uid(), P.p1, 'ortodoncia', '2026-04-28', '09:00:00', 45, 'completada',  'Control mensual mes 14', U.sec],
      [uid(), P.p3, 'consulta',   '2026-04-29', '09:00:00', 30, 'programada',  'Primera visita',         U.sec],
      [uid(), P.p2, 'endodoncia', '2026-04-29', '10:00:00', 60, 'programada',  'Sesión 2 - Medicación',  U.sec],
      [uid(), P.p4, 'ortodoncia', '2026-05-02', '10:00:00', 45, 'programada',  'Control mes 8',          U.sec],
      [uid(), P.p5, 'endodoncia', '2026-04-28', '11:00:00', 60, 'completada',  'Sesión 1 - Apertura',    U.sec],
      [uid(), P.p1, 'ortodoncia', '2026-05-15', '09:00:00', 45, 'programada',  'Control mensual mes 15', U.sec],
    ];
    for (const c of citas) {
      await conn.query(
        `INSERT INTO citas (id,paciente_id,tipo,fecha,hora,duracion_min,estado,notas,created_by) VALUES (?,?,?,?,?,?,?,?,?)`, c
      );
    }
    console.log('✅ 6 citas');

    /* ── Ortodoncias ── */
    const OR1 = uid(), OR2 = uid();
    await conn.query(
      `INSERT INTO ortodoncias (id,paciente_id,tipo_aparato,fecha_inicio,duracion_meses,costo_total,pagado_total) VALUES (?,?,?,?,?,?,?)`,
      [OR1, P.p1, 'metálico', '2025-02-10', 24, 4320.00, 2520.00]
    );
    await conn.query(
      `INSERT INTO ortodoncias (id,paciente_id,tipo_aparato,fecha_inicio,duracion_meses,costo_total,pagado_total) VALUES (?,?,?,?,?,?,?)`,
      [OR2, P.p4, 'cerámico', '2025-08-15', 18, 3600.00, 1800.00]
    );

    const sesOrto = [
      [uid(), OR1,  1, '2025-02-10', 'Nitinol 0.012', 'Sin ligas',          'Brackets colocados. Inicio tratamiento.',     U.doc],
      [uid(), OR1,  6, '2025-07-12', 'Nitinol 0.014', 'Sin ligas',          'Buen alineamiento. Cambio a arco mayor.',     U.res],
      [uid(), OR1, 12, '2026-02-14', 'SS 0.016',      'Clase II bilateral', 'Corrección de resalte mejorando.',            U.res],
      [uid(), OR1, 13, '2026-03-18', 'SS 0.016',      'Clase II bilateral', 'Sin cambio de arco. Progreso estable.',       U.res],
      [uid(), OR1, 14, '2026-04-15', 'SS 0.016',      'Clase II bilateral', 'Cambio exitoso. Se nota cierre de diastema.', U.res],
    ];
    for (const s of sesOrto) {
      await conn.query(
        `INSERT INTO ortodoncia_sesiones (id,ortodoncia_id,mes_numero,fecha,arco_activo,ligas,nota,realizado_por) VALUES (?,?,?,?,?,?,?,?)`, s
      );
    }
    console.log('✅ Ortodoncias y sesiones');

    /* ── Endodoncias ── */
    const EN1 = uid(), EN2 = uid();
    await conn.query(
      `INSERT INTO endodoncias (id,paciente_id,diente,num_conductos,fase_actual,costo) VALUES (?,?,?,?,?,?)`,
      [EN1, P.p2, 36, 3, 3, 850.00]
    );
    await conn.query(
      `INSERT INTO endodoncias (id,paciente_id,diente,num_conductos,fase_actual,costo) VALUES (?,?,?,?,?,?)`,
      [EN2, P.p5, 46, 2, 2, 750.00]
    );

    const sesEndo = [
      [uid(), EN1, 1, '2026-03-15', 1, JSON.stringify([{nombre:'MB',estado:'listo'},{nombre:'ML',estado:'pendiente'},{nombre:'D',estado:'pendiente'}]), 'Apertura realizada. Anestesia sin complicaciones.', U.doc],
      [uid(), EN1, 2, '2026-04-01', 2, JSON.stringify([{nombre:'MB',estado:'listo'},{nombre:'ML',estado:'proceso'},{nombre:'D',estado:'pendiente'}]),   'Conductometría: MB=20mm, ML=19mm. Sin perforación.', U.res],
      [uid(), EN2, 1, '2026-04-28', 1, JSON.stringify([{nombre:'MB',estado:'listo'},{nombre:'D',estado:'pendiente'}]),                                   'Apertura y localización conductos MB y D.', U.res],
    ];
    for (const s of sesEndo) {
      await conn.query(
        `INSERT INTO endodoncia_sesiones (id,endodoncia_id,numero_sesion,fecha,fase_completada,conductos_json,nota_clinica,realizado_por) VALUES (?,?,?,?,?,?,?,?)`, s
      );
    }
    console.log('✅ Endodoncias y sesiones');

    /* ── Pagos ── */
    const hoy = new Date().toISOString().slice(0,10);
    const pagos = [
      [uid(), P.p1, 'Mensualidad Ortodoncia Mes 1',   180.00, 'efectivo',      'pagado',    '2025-02-10', U.sec],
      [uid(), P.p1, 'Mensualidad Ortodoncia Mes 2',   180.00, 'yape',          'pagado',    '2025-03-10', U.sec],
      [uid(), P.p1, 'Mensualidad Ortodoncia Mes 3',   180.00, 'transferencia', 'pagado',    '2025-04-10', U.sec],
      [uid(), P.p1, 'Mensualidad Ortodoncia Mes 14',  180.00, 'tarjeta',       'pagado',    '2026-04-10', U.sec],
      [uid(), P.p1, 'Mensualidad Ortodoncia Mes 15',  180.00, 'efectivo',      'pendiente', '2026-05-10', U.sec],
      [uid(), P.p2, 'Endodoncia D.36 — Sesión 1',    280.00, 'efectivo',      'pagado',    '2026-03-15', U.sec],
      [uid(), P.p2, 'Endodoncia D.36 — Sesión 2',    350.00, 'tarjeta',       'pendiente', '2026-04-01', U.sec],
      [uid(), P.p3, '1ª Consulta',                    80.00, 'tarjeta',       'pagado',    '2026-04-29', U.sec],
      [uid(), P.p4, 'Mensualidad Ortodoncia Mes 8',  180.00, 'yape',          'pagado',    '2026-04-27', U.sec],
    ];
    for (const p of pagos) {
      await conn.query(
        `INSERT INTO pagos (id,paciente_id,concepto,monto,metodo,estado,fecha,registrado_por) VALUES (?,?,?,?,?,?,?,?)`, p
      );
    }
    console.log('✅ 9 pagos');

    console.log(`
🎉 Seed completado. Base de datos lista.

   Credenciales (contraseña: dental123):
   📋 secretaria@dentalcare.pe
   🦷 residente@dentalcare.pe
   👩‍⚕️ doctor@dentalcare.pe
`);

  } catch (err) {
    console.error('❌ Error en seed:', err.message);
    throw err;
  } finally {
    await conn.end();
  }
}

seed().catch(() => process.exit(1));
