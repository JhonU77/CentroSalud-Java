/**
 * DentalCare · db/migrate.js  (MySQL 8.0 CE compatible)
 * Ejecutar: node db/migrate.js
 */

const mysql = require('mysql2/promise');
require('dotenv').config();

async function migrate() {
  const conn = await mysql.createConnection({
    host:               process.env.DB_HOST     || 'localhost',
    port:               parseInt(process.env.DB_PORT || '3306'),
    user:               process.env.DB_USER     || 'root',
    password:           process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  console.log('🦷 DentalCare — Creando base de datos y tablas en MySQL 8.0...\n');

  try {
    const DB = process.env.DB_NAME || 'dentalcare';

    await conn.query(
      `CREATE DATABASE IF NOT EXISTS \`${DB}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    await conn.query(`USE \`${DB}\``);
    console.log(`✅ Base de datos "${DB}" lista`);

    /* ── USUARIOS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id           VARCHAR(8)   NOT NULL,
        nombre       VARCHAR(120) NOT NULL,
        email        VARCHAR(180) NOT NULL,
        password     VARCHAR(255) NOT NULL,
        rol          ENUM('secretaria','residente','doctor') NOT NULL,
        titulo       VARCHAR(120) NOT NULL,
        iniciales    VARCHAR(3)   NOT NULL,
        avatar_color VARCHAR(10)  DEFAULT '#1D9E75',
        activo       TINYINT(1)   DEFAULT 1,
        created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
        updated_at   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_email (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ usuarios');

    /* ── PACIENTES ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS pacientes (
        id               VARCHAR(8)   NOT NULL,
        expediente       VARCHAR(10)  NOT NULL,
        nombre           VARCHAR(80)  NOT NULL,
        apellido         VARCHAR(120) NOT NULL,
        fecha_nacimiento DATE,
        telefono         VARCHAR(20)  NOT NULL,
        email            VARCHAR(180),
        alergias         JSON,
        motivo_inicial   TEXT,
        notas_generales  TEXT,
        activo           TINYINT(1)   DEFAULT 1,
        created_by       VARCHAR(8),
        created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
        updated_at       DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_expediente (expediente),
        INDEX idx_nombre   (nombre, apellido),
        INDEX idx_telefono (telefono)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ pacientes');

    /* ── CITAS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS citas (
        id           VARCHAR(8)   NOT NULL,
        paciente_id  VARCHAR(8)   NOT NULL,
        tipo         ENUM('ortodoncia','endodoncia','consulta','otro') NOT NULL,
        fecha        DATE         NOT NULL,
        hora         TIME         NOT NULL,
        duracion_min SMALLINT     DEFAULT 45,
        estado       ENUM('programada','completada','cancelada','no_asistio') DEFAULT 'programada',
        notas        TEXT,
        recordatorio VARCHAR(10)  DEFAULT '24h',
        created_by   VARCHAR(8),
        created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
        updated_at   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_fecha    (fecha),
        INDEX idx_paciente (paciente_id),
        CONSTRAINT fk_citas_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ citas');

    /* ── ORTODONCIAS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS ortodoncias (
        id             VARCHAR(8)      NOT NULL,
        paciente_id    VARCHAR(8)      NOT NULL,
        tipo_aparato   VARCHAR(40)     DEFAULT 'metálico',
        fecha_inicio   DATE            NOT NULL,
        duracion_meses TINYINT UNSIGNED DEFAULT 24,
        costo_total    DECIMAL(10,2)   DEFAULT 0.00,
        pagado_total   DECIMAL(10,2)   DEFAULT 0.00,
        estado         ENUM('activo','completado','abandonado') DEFAULT 'activo',
        notas          TEXT,
        created_at     DATETIME        DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_paciente_ortodoncia (paciente_id),
        CONSTRAINT fk_ortodoncia_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS ortodoncia_sesiones (
        id            VARCHAR(8)   NOT NULL,
        ortodoncia_id VARCHAR(8)   NOT NULL,
        mes_numero    TINYINT      NOT NULL,
        fecha         DATE         NOT NULL,
        arco_activo   VARCHAR(60)  DEFAULT '',
        ligas         VARCHAR(120) DEFAULT '',
        nota          TEXT,
        foto_path     VARCHAR(255) DEFAULT '',
        realizado_por VARCHAR(8),
        created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_ortodoncia (ortodoncia_id),
        CONSTRAINT fk_sesion_ortodoncia FOREIGN KEY (ortodoncia_id) REFERENCES ortodoncias(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ ortodoncias + ortodoncia_sesiones');

    /* ── ENDODONCIAS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS endodoncias (
        id            VARCHAR(8)    NOT NULL,
        paciente_id   VARCHAR(8)    NOT NULL,
        diente        TINYINT       NOT NULL,
        num_conductos TINYINT       DEFAULT 1,
        fase_actual   TINYINT       DEFAULT 1,
        estado        ENUM('activo','completado','derivado') DEFAULT 'activo',
        costo         DECIMAL(10,2) DEFAULT 0.00,
        created_at    DATETIME      DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_paciente (paciente_id),
        CONSTRAINT fk_endodoncia_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    await conn.query(`
      CREATE TABLE IF NOT EXISTS endodoncia_sesiones (
        id               VARCHAR(8)   NOT NULL,
        endodoncia_id    VARCHAR(8)   NOT NULL,
        numero_sesion    TINYINT      NOT NULL,
        fecha            DATE         NOT NULL,
        fase_completada  TINYINT      NOT NULL,
        conductos_json   JSON,
        nota_clinica     TEXT,
        radiografia_path VARCHAR(255) DEFAULT '',
        realizado_por    VARCHAR(8),
        created_at       DATETIME     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_endodoncia (endodoncia_id),
        CONSTRAINT fk_sesion_endodoncia FOREIGN KEY (endodoncia_id) REFERENCES endodoncias(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ endodoncias + endodoncia_sesiones');

    /* ── PAGOS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS pagos (
        id             VARCHAR(8)    NOT NULL,
        paciente_id    VARCHAR(8)    NOT NULL,
        concepto       VARCHAR(200)  NOT NULL,
        monto          DECIMAL(10,2) NOT NULL,
        metodo         ENUM('efectivo','tarjeta','yape','transferencia','otro') DEFAULT 'efectivo',
        estado         ENUM('pagado','pendiente','anulado') DEFAULT 'pagado',
        fecha          DATE          NOT NULL,
        registrado_por VARCHAR(8),
        created_at     DATETIME      DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_paciente (paciente_id),
        INDEX idx_fecha    (fecha),
        CONSTRAINT fk_pago_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ pagos');

    /* ── ARCHIVOS ── */
    await conn.query(`
      CREATE TABLE IF NOT EXISTS archivos (
        id            VARCHAR(8)   NOT NULL,
        paciente_id   VARCHAR(8)   NOT NULL,
        tipo          ENUM('foto','radiografia','documento') NOT NULL,
        subtipo       VARCHAR(60)  DEFAULT '',
        filename      VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        size_bytes    INT          DEFAULT 0,
        mime_type     VARCHAR(80)  DEFAULT '',
        nota          TEXT,
        subido_por    VARCHAR(8),
        created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX idx_paciente (paciente_id),
        CONSTRAINT fk_archivo_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('   ✓ archivos');

    console.log('\n🎉 Migración completada. Todas las tablas listas en MySQL 8.0.\n');

  } catch (err) {
    console.error('\n❌ Error en migración:', err.message);
    console.error('   Código MySQL:', err.code);
    throw err;
  } finally {
    await conn.end();
  }
}

migrate().catch(() => process.exit(1));
