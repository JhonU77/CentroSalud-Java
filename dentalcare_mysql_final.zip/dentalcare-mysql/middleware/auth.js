/**
 * DentalCare · middleware/auth.js
 */

const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ ok: false, error: 'No autenticado' });
  }
  try {
    req.user = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET || 'dentalcare_secret');
    next();
  } catch {
    return res.status(401).json({ ok: false, error: 'Token inválido o expirado' });
  }
}

function requireRol(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ ok: false, error: 'No autenticado' });
    if (!roles.includes(req.user.rol)) {
      return res.status(403).json({ ok: false, error: `Acceso denegado. Rol requerido: ${roles.join(' o ')}` });
    }
    next();
  };
}

module.exports = { requireAuth, requireRol };
